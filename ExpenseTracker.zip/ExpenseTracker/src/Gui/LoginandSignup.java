package Gui;

public class LoginandSignup {
    public static void main(String args[]) {
        
        Login Loginframe = new Login();
        Loginframe.setVisible(true);
        Loginframe.pack();
        Loginframe.setLocationRelativeTo(null);
        
    }
}
