/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;
import java.sql.*;
import javax.swing.JOptionPane;
public class DbConnect {
   public static Connection c; 
   public static Statement st;
   //when loaded value started
   static{
       try{
           c = DriverManager.getConnection("jdbc:mysql://localhost:3305/spendingdb"+"?useSSL=false", "root", "W7301@jqir#");
           st = c.createStatement();
       }catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);        }
   }
}
